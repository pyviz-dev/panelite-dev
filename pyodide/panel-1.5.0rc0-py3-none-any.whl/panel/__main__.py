import sys


def main():
    from panel.command import main as _main

   # Main entry point (see setup.py)
    _main(sys.argv)

if __name__ == "__main__":
    main()
